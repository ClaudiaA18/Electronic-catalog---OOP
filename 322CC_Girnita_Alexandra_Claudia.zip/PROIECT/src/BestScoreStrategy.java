import java.util.ArrayList;

public interface BestScoreStrategy {
    public Student getBestStudent(Course course);
}
